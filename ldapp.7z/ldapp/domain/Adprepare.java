package com.ld.ldapp.domain;

import lombok.Data;

@Data
public class Adprepare {
    private Integer id;
    private String title;
    private Integer level;
    private String imgurl;
    private String context;
    private String auth;
    private String date;

}
