package com.ld.ldapp.domain;

import com.github.pagehelper.PageInfo;
import lombok.Data;

import java.lang.reflect.Array;
import java.util.List;

@Data
public class ReturnData {


    private String code;
    private Object data;
    private String massage;

    public ReturnData(String massage){

        this.code="102";
        this.massage=massage;
    }

    public ReturnData(Object data){

        this.code="100";
        this.data=data;
        if(data instanceof java.util.List){
        }
        this.massage="成功";
    }

    public ReturnData(){

        this.code="101";
        this.data=null;
        this.massage="数据效验失败";
    }



}
