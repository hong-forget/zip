package com.ld.ldapp.domain;

import lombok.Data;

@Data
public class Rujin {
    private Integer id;
    private String name;
    private String img;
    private String account;
    private Integer sum;
}
