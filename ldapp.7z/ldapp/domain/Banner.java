package com.ld.ldapp.domain;

import lombok.Data;

@Data
public class Banner {


    private Integer id;
    private String img;
    private  String context;
    private Integer level;
    private  String title;
    private String auth;
    private String date;

}
