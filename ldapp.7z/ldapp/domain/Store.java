package com.ld.ldapp.domain;

import lombok.Data;

@Data
public class Store {
    private Integer id;
    private String storecode;
    private String storename;
}
