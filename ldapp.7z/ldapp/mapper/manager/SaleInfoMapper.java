package com.ld.ldapp.mapper.manager;

import com.alibaba.fastjson.JSONObject;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

public interface SaleInfoMapper {

    @Select("select t.*,c.commissions from \n" +
            "(select s.*,b.address,b.id bId,b.`name`,b.`index`,date_format(s.validity,'%Y-%m-%d %H:%i:%s') fValidity from b_sale_Info s RIGHT JOIN building b on s.b_id=b.id where IFNULL(b.del,0)<>1)t\n" +
            " LEFT JOIN \n" +
            "( SELECT COUNT(1) commissions,b_id FROM b_commission GROUP BY b_id)c \n" +
            "ON c.b_id=t.b_id ORDER BY t.`index` DESC")
    List<Map> list(JSONObject param);

    @Insert("INSERT INTO `b_sale_Info` " +
            "(`b_id`, `phone_style`, `time_out`, `validity`, `status`, `record_explan`,lcpinfo,show_explan,pay_explan,precord_time,vrecord_time,lcpIds) VALUES " +
            "(#{b_id}, #{phone_style}, #{time_out}, #{validity}, #{status}, #{record_explan},#{lcpinfo},#{show_explan},#{pay_explan},#{precord_time},#{vrecord_time},#{lcpIds})")
    Integer add(JSONObject param);

    @Update("<script> UPDATE `b_sale_Info`" +
            "<trim prefix=\"SET\" suffixOverrides=\",\" suffix=\" WHERE (`id`=#{id}) \">" +
            "<if test=\" b_id!=null \"> `b_id`=#{b_id}, </if>" +
            "<if test=\" phone_style!=null \"> `phone_style`=#{phone_style}, </if>" +
            "<if test=\" time_out!=null \"> `time_out`=#{time_out}, </if>" +
            "<if test=\" validity!=null \"> `validity`=#{validity}, </if>" +
            "<if test=\" status!=null \"> `status`=#{status}, </if>" +
            "<if test=\" record_explan!=null \"> `record_explan`=#{record_explan}, </if>" +
            "<if test=\" lcpinfo!=null \"> `lcpinfo`=#{lcpinfo}, </if>" +
            "<if test=\" show_explan!=null \"> `show_explan`=#{show_explan}, </if>" +
            "<if test=\" pay_explan!=null \"> `pay_explan`=#{pay_explan}, </if>" +
            "<if test=\" precord_time!=null \"> `precord_time`=#{precord_time}, </if>" +
            "<if test=\" vrecord_time!=null \"> `vrecord_time`=#{vrecord_time}, </if>" +
            "<if test=\" lcpIds!=null \"> `lcpIds`=#{lcpIds}, </if>" +
            "</trim></script>")
    Integer modify(JSONObject param);

    @Update("UPDATE building set `index`= `index`-1 where `index`>#{index}")
    Integer updateAll(Integer index, Integer maxIndex);

    @Update("UPDATE building set `index`=#{maxIndex} \n" +
            " where `id`=#{bId}")
    Integer setMaxIndex(Integer bId, Integer maxIndex);

    @Update("UPDATE building set `index`=`index`-1 \n" +
            " where `index`=#{index}")
    Integer updatePre(Integer index);

    @Update("UPDATE building set `index`=`index`+1 \n" +
            " where `index`=#{index}-1")
    Integer updateNext(Integer index);

    @Update("UPDATE building set `index`=#{index} \n" +
            " where `id`=#{bId}")
    Integer setIndex(Integer index,Integer bId);

    @Insert("INSERT INTO `b_commission` (`title`, `commission`, `f_commission`, `b_commission`, `b_id`,`unit`,`remark`) VALUES (#{title}, #{commission}, #{fCommission}, #{bCommission}, #{b_id},#{unit},#{remark})")
    Integer addCommission(JSONObject commissionObj);

    @Update("UPDATE `b_commission` SET `title`=#{title}, `commission`=#{commission}, `f_commission`=#{fCommission}, `b_commission`=#{bCommission},`unit`=#{unit}, `b_id`=#{b_id} WHERE (`id`=#{id})")
    Integer modifyCommission(JSONObject commissionObj);

    @Delete("DELETE FROM `b_commission` WHERE (`b_id`=#{b_id})")
    Integer delCommissions(Integer b_id);

    @Select("SELECT * FROM `b_commission` WHERE b_id=#{bId} ")
    List<Map> commissionList(JSONObject param);

    @Select("SELECT * FROM `b_commission` WHERE b_id=#{bId} ")
    JSONObject findOne(JSONObject param);
}
