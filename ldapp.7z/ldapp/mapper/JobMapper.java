package com.ld.ldapp.mapper;

import com.ld.ldapp.domain.Job;

import java.util.List;

public interface JobMapper {

    List<Job> findAll();

}
