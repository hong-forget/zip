package com.ld.ldapp.advice;

import org.springframework.web.bind.annotation.ControllerAdvice;

import javax.annotation.Resource;

//@ControllerAdvice
public class MyControllerAdvice {


}