package com.ld.ldapp.controller.manager;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.ld.ldapp.domain.ReturnData;
import com.ld.ldapp.mapper.BuildManagerMapper;
import com.ld.ldapp.mapper.MUserMapper;
import com.ld.ldapp.mapper.manager.SaleInfoMapper;
import com.ld.ldapp.util.MyUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SaleInfoController {

    @Autowired
    SaleInfoMapper saleInfoMapper;

    @Autowired
    MUserMapper mUserMapper;

    @Autowired
    BuildManagerMapper buildManagerMapper;

    @PostMapping("/saleinfo/modify")
    public ReturnData modify(@RequestBody JSONObject param){


        updateLcp(param.getString("lcpIds"),param.getInteger("b_id"));
        JSONArray commissions=param.getJSONArray("commissions");
        if(commissions!=null){
            saleInfoMapper.delCommissions(param.getInteger("b_id"));
            updateCommissions(commissions);
        }

        if(param.getInteger("id")==null){

            return new ReturnData(saleInfoMapper.add(param));
        }else {


            return new ReturnData(saleInfoMapper.modify(param));
        }

    }

    private void updateCommissions(JSONArray commissions) {
        for (Object commission : commissions) {
            JSONObject commissionObj=(JSONObject) commission;
            if(commissionObj!=null){
                saleInfoMapper.addCommission(commissionObj);
            }
        }

    }

    @PostMapping("/saleinfo/commissions")
    public ReturnData commissions(@RequestBody JSONObject param){



        return new ReturnData(MyUtil.getPageInfo(saleInfoMapper.commissionList(param)));
    }

    @PostMapping("/saleinfo/list")
    public ReturnData list(@RequestBody JSONObject param){



        return new ReturnData(MyUtil.getPageInfo(saleInfoMapper.list(param)));
    }

    @PostMapping("/saleinfo/index")
    public ReturnData index(@RequestBody JSONObject param){

        if(param.getInteger("type")==1){
            Integer maxIndex=buildManagerMapper.getBIndex();
            saleInfoMapper.updateAll(param.getInteger("index"),maxIndex);
            saleInfoMapper.setMaxIndex(param.getInteger("bId"),maxIndex);
        }else if(param.getInteger("type")==2){

            saleInfoMapper.updatePre(param.getInteger("index")+1);
            saleInfoMapper.setIndex(param.getInteger("index")+1,param.getInteger("bId"));
        }else if(param.getInteger("type")==3){

            saleInfoMapper.updateNext(param.getInteger("index"));
            saleInfoMapper.setIndex(param.getInteger("index")-1,param.getInteger("bId"));
        }


        return new ReturnData(1);
    }

    private void updateLcp(String ids,Integer bId){


        mUserMapper.delLcps(bId);
        if(ids!=null&&!ids.isEmpty()){
            String[] lcps=ids.split(",");
            for (String lcp : lcps) {
                mUserMapper.addLcp(Integer.parseInt(lcp),bId);
            }
        }
    }



}
