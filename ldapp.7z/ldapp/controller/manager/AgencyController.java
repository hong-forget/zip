package com.ld.ldapp.controller.manager;

import com.alibaba.fastjson.JSONObject;
import com.ld.ldapp.domain.ReturnData;
import com.ld.ldapp.mapper.MUserMapper;
import com.ld.ldapp.mapper.manager.AgencyMapper;
import com.ld.ldapp.util.MyUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController()
public class AgencyController {

    @Autowired
    AgencyMapper agencyMapper;

    @Autowired
    MUserMapper mUserMapper;

    @PostMapping("/agency/list")
    public ReturnData list(@RequestBody(required = false) JSONObject param){
        MyUtil.setPage(param);
        return new ReturnData(agencyMapper.list(param));
    }

    @PostMapping("/agency/mdify")
    public ReturnData mdify(@RequestBody(required = false) JSONObject param){


        if(param.getInteger("id")==null){

            Integer i=agencyMapper.add(param);
            if(param.getInteger("agent_id")!=null)
            updateAgent(param.getInteger("agent_id"),param.getInteger("id"));

            return new ReturnData(i);

        }else{

            if(param.getInteger("agent_id")!=null)
            updateAgent(param.getInteger("agent_id"),param.getInteger("id"));
            return new ReturnData(agencyMapper.mdify(param));
        }
    }

    @PostMapping("/agency/read")
    public ReturnData read(@RequestBody(required = false) JSONObject param){

        return new ReturnData(agencyMapper.read(param));

    }

    @PostMapping("/agency/realtor")
    public ReturnData realtor(@RequestBody(required = false) JSONObject param){

        return new ReturnData(agencyMapper.realtor(param));

    }

    @PostMapping("/agency/statistic")
    public ReturnData statistic(@RequestBody(required = false) JSONObject param){

        return new ReturnData(agencyMapper.statistic(param));

    }

    private void updateAgent(Integer uid,Integer sid){


        mUserMapper.delAgent(uid,sid);

        mUserMapper.addAgent(uid,sid);
    }

    @PostMapping("/agency/checkcode")
    public ReturnData checkAgencyCode(@RequestBody JSONObject param){
        return new ReturnData();
    }

}
