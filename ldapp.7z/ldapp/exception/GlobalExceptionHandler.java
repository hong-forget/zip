package com.ld.ldapp.exception;

public class GlobalExceptionHandler {

}
